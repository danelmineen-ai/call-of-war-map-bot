# Call of War Scenario Maps — Telegram bot prototype

## What it does
- `/start` or `/scenarios` shows a menu of known Call of War scenarios.
- Shows reference information and source links for the selected scenario.
- Asks the user to upload a screenshot of the scenario map from the game.
- Creates a titled PNG reference card from that screenshot and a JSON reference record.

## Important limitations
- Scenario availability and player counts can change between game versions and events.
- The bot does not reconstruct exact province boundaries from scratch.
- It does not create a game round, upload a map to Call of War servers, or bypass the game's own tools.
- JSON is this project's own reference format, not an official Call of War import format.
- For a faithful map image, a screenshot from the user's game is needed.

## Run
1. Create a bot using Telegram's official `@BotFather`.
2. Set the token as `BOT_TOKEN` in your hosting service's secrets/environment settings.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python bot.py`

Keep your token private. Do not commit it to GitHub.
