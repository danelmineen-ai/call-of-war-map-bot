import os
import json
import tempfile
from datetime import date

import telebot
from telebot import types
from PIL import Image, ImageDraw, ImageFont

TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise RuntimeError("Set BOT_TOKEN in your hosting service's environment/secrets.")

bot = telebot.TeleBot(TOKEN)

# Scenario references. Availability/player counts may change by game version or event.
SCENARIOS = {
    "historic1939": {
        "name": "1939 - Historical World War",
        "players": "30 players (historically reported; may change)",
        "description": "Historical world map representing the political situation around 1939.",
        "source": "https://forum.callofwar.com/index.php?thread/11326-epic-new-historical-world-map/"
    },
    "worldatwar": {
        "name": "World at War",
        "players": "100-player scenario (historically listed; may change)",
        "description": "Large world-wide strategy scenario.",
        "source": "https://wiki.callofwar.com/wiki/Main_Page"
    },
    "europeclash": {
        "name": "Europe - Clash of Nations",
        "players": "22 players (official FAQ listing; may change)",
        "description": "European regional scenario.",
        "source": "https://wiki.callofwar.com/wiki/FAQ"
    },
    "europetowar": {
        "name": "Europe - Road to War",
        "players": "12 players (official FAQ listing; may change)",
        "description": "European regional scenario.",
        "source": "https://wiki.callofwar.com/wiki/FAQ"
    },
    "blitzkrieg1939": {
        "name": "1939 - Blitzkrieg",
        "players": "10 players (official FAQ listing; may change)",
        "description": "Historical European theatre scenario set around 1939.",
        "source": "https://wiki.callofwar.com/wiki/FAQ"
    }
}

pending_scenario = {}

def get_font(size=22, bold=False):
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf",
    ]
    for path in paths:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    return ImageFont.load_default()

def scenario_keyboard():
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    for key, item in SCENARIOS.items():
        keyboard.add(types.InlineKeyboardButton(item["name"], callback_data="scenario:" + key))
    return keyboard

@bot.message_handler(commands=["start", "help", "scenarios"])
def show_scenarios(message):
    bot.send_message(
        message.chat.id,
        "🗺 Call of War Scenario Maps\\n\\n"
        "Выбери существующий сценарий. Я покажу справочную информацию и попрошу прислать "
        "скриншот карты из игры, чтобы сделать PNG-карточку именно этого сценария.\\n\\n"
        "Важно: бот не создаёт игровую партию и не загружает карты на серверы игры. "
        "Официальный формат импорта пользовательских карт не подтверждён.",
        reply_markup=scenario_keyboard()
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("scenario:"))
def choose_scenario(call):
    key = call.data.split(":", 1)[1]
    scenario = SCENARIOS.get(key)
    if not scenario:
        bot.answer_callback_query(call.id, "Сценарий не найден.")
        return
    pending_scenario[call.message.chat.id] = key
    bot.answer_callback_query(call.id)
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton("Открыть источник", url=scenario["source"]))
    bot.send_message(
        call.message.chat.id,
        f"🗺 {scenario['name']}\\n\\n"
        f"Игроки: {scenario['players']}\\n"
        f"{scenario['description']}\\n\\n"
        "Пришли скриншот карты этого сценария из игры. Я добавлю название и подготовлю "
        "PNG-карточку и JSON-описание. Доступность сценариев может меняться.",
        reply_markup=keyboard
    )

@bot.message_handler(content_types=["photo"])
def receive_screenshot(message):
    chat_id = message.chat.id
    key = pending_scenario.get(chat_id)
    if not key:
        bot.reply_to(message, "Сначала выбери сценарий командой /scenarios.")
        return

    scenario = SCENARIOS[key]
    photo = message.photo[-1]
    file_info = bot.get_file(photo.file_id)
    data = bot.download_file(file_info.file_path)

    with tempfile.TemporaryDirectory() as tmp:
        original_path = os.path.join(tmp, "uploaded_map.jpg")
        output_path = os.path.join(tmp, "scenario_map.png")
        json_path = os.path.join(tmp, "scenario.json")
        with open(original_path, "wb") as file:
            file.write(data)

        image = Image.open(original_path).convert("RGB")
        header_h = max(74, image.width // 10)
        footer_h = max(42, image.width // 18)
        canvas = Image.new("RGB", (image.width, image.height + header_h + footer_h), "#172b3a")
        canvas.paste(image, (0, header_h))
        draw = ImageDraw.Draw(canvas)
        title_size = max(18, min(42, image.width // 28))
        draw.text((18, 12), scenario["name"], fill="white", font=get_font(title_size, True))
        draw.text((18, header_h + image.height + 8),
                  "User screenshot • Reference card, not an import file",
                  fill="#e1eaf0", font=get_font(max(12, image.width // 70)))
        canvas.save(output_path)

        payload = {
            "format": "call_of_war_scenario_reference_v1",
            "scenario_name": scenario["name"],
            "players": scenario["players"],
            "description": scenario["description"],
            "source": scenario["source"],
            "created_date": date.today().isoformat(),
            "image_origin": "Screenshot supplied by the user from the game",
            "compatibility": {
                "official_game_import": False,
                "note": "This JSON is a reference record, not an official Call of War import format."
            }
        }
        with open(json_path, "w", encoding="utf-8") as file:
            json.dump(payload, file, ensure_ascii=False, indent=2)

        with open(output_path, "rb") as file:
            bot.send_photo(chat_id, file, caption="Готова PNG-карточка выбранного сценария.")
        with open(json_path, "rb") as file:
            bot.send_document(chat_id, file, caption="JSON-справка о сценарии; не является файлом импорта в игру.")

    pending_scenario.pop(chat_id, None)

@bot.message_handler(func=lambda message: True, content_types=["text"])
def other_text(message):
    bot.reply_to(message, "Напиши /scenarios, чтобы выбрать существующий сценарий.")

if __name__ == "__main__":
    print("Call of War Scenario Maps bot is running.")
    bot.infinity_polling(skip_pending=True)
